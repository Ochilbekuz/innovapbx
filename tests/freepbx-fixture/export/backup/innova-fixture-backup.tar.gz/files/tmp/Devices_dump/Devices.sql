/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: db    Database: asterisk
-- ------------------------------------------------------
-- Server version	10.6.28-MariaDB-ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `devices`
--

DROP TABLE IF EXISTS `devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `devices` (
  `id` varchar(20) NOT NULL DEFAULT '',
  `tech` varchar(10) NOT NULL DEFAULT '',
  `dial` varchar(255) NOT NULL DEFAULT '',
  `devicetype` varchar(5) NOT NULL DEFAULT '',
  `user` varchar(50) DEFAULT NULL,
  `description` varchar(80) DEFAULT NULL,
  `emergency_cid` varchar(100) DEFAULT NULL,
  `hint_override` varchar(100) DEFAULT NULL,
  KEY `id` (`id`),
  KEY `tech` (`tech`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `devices`
--

LOCK TABLES `devices` WRITE;
/*!40000 ALTER TABLE `devices` DISABLE KEYS */;
INSERT INTO `devices` VALUES
('101','pjsip','PJSIP/101','fixed','101','Sinov Bir','',''),
('102','pjsip','PJSIP/102','fixed','102','Sinov Ikki (CF)','',''),
('103','pjsip','PJSIP/103','fixed','103','Sinov Uch','',''),
('105','pjsip','PJSIP/105','fixed','105','Sinov Besh (VM)','',''),
('106','pjsip','PJSIP/106','fixed','106','Sinov Olti (CID+DND)','',''),
('107','pjsip','PJSIP/107','fixed','107','Sinov Yetti (FollowMe)','','');
/*!40000 ALTER TABLE `devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sip`
--

DROP TABLE IF EXISTS `sip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sip` (
  `id` varchar(20) NOT NULL DEFAULT '-1',
  `keyword` varchar(30) NOT NULL DEFAULT '',
  `data` varchar(8100) NOT NULL,
  `flags` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`,`keyword`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sip`
--

LOCK TABLES `sip` WRITE;
/*!40000 ALTER TABLE `sip` DISABLE KEYS */;
INSERT INTO `sip` VALUES
('101','account','101',13),
('101','allow','ulaw,alaw,g722',12),
('101','callerid','Sinov Bir <101>',14),
('101','canreinvite','no',7),
('101','context','from-internal',5),
('101','dial','PJSIP/101',2),
('101','disallow','all',11),
('101','dtmfmode','rfc2833',6),
('101','host','dynamic',9),
('101','max_contacts','1',0),
('101','port','',8),
('101','qualifyfreq','60',4),
('101','remove_existing','yes',0),
('101','secret','SinovSecret101!',3),
('101','type','friend',10),
('102','account','102',13),
('102','allow','ulaw,alaw,g722',12),
('102','callerid','Sinov Ikki (CF) <102>',14),
('102','canreinvite','no',7),
('102','context','from-internal',5),
('102','dial','PJSIP/102',2),
('102','disallow','all',11),
('102','dtmfmode','rfc2833',6),
('102','host','dynamic',9),
('102','max_contacts','1',0),
('102','port','',8),
('102','qualifyfreq','60',4),
('102','remove_existing','yes',0),
('102','secret','SinovSecret102!',3),
('102','type','friend',10),
('103','account','103',13),
('103','allow','ulaw,alaw,g722',12),
('103','callerid','Sinov Uch <103>',14),
('103','canreinvite','no',7),
('103','context','from-internal',5),
('103','dial','PJSIP/103',2),
('103','disallow','all',11),
('103','dtmfmode','rfc2833',6),
('103','host','dynamic',9),
('103','max_contacts','1',0),
('103','port','',8),
('103','qualifyfreq','60',4),
('103','remove_existing','yes',0),
('103','secret','SinovSecret103!',3),
('103','type','friend',10),
('105','account','105',13),
('105','allow','ulaw,alaw,g722',12),
('105','callerid','Sinov Besh (VM) <105>',14),
('105','canreinvite','no',7),
('105','context','from-internal',5),
('105','dial','PJSIP/105',2),
('105','disallow','all',11),
('105','dtmfmode','rfc2833',6),
('105','host','dynamic',9),
('105','max_contacts','1',0),
('105','port','',8),
('105','qualifyfreq','60',4),
('105','remove_existing','yes',0),
('105','secret','SinovSecret105!',3),
('105','type','friend',10),
('106','account','106',13),
('106','allow','ulaw,alaw,g722',12),
('106','callerid','Sinov Olti (CID+DND) <106>',14),
('106','canreinvite','no',7),
('106','context','from-internal',5),
('106','dial','PJSIP/106',2),
('106','disallow','all',11),
('106','dtmfmode','rfc2833',6),
('106','host','dynamic',9),
('106','max_contacts','1',0),
('106','port','',8),
('106','qualifyfreq','60',4),
('106','remove_existing','yes',0),
('106','secret','SinovSecret106!',3),
('106','type','friend',10),
('107','account','107',13),
('107','allow','ulaw,alaw,g722',12),
('107','callerid','Sinov Yetti (FollowMe) <107>',14),
('107','canreinvite','no',7),
('107','context','from-internal',5),
('107','dial','PJSIP/107',2),
('107','disallow','all',11),
('107','dtmfmode','rfc2833',6),
('107','host','dynamic',9),
('107','max_contacts','1',0),
('107','port','',8),
('107','qualifyfreq','60',4),
('107','remove_existing','yes',0),
('107','secret','SinovSecret107!',3),
('107','type','friend',10);
/*!40000 ALTER TABLE `sip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dahdi`
--

DROP TABLE IF EXISTS `dahdi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `dahdi` (
  `id` varchar(20) NOT NULL DEFAULT '-1',
  `keyword` varchar(30) NOT NULL DEFAULT '',
  `data` varchar(255) NOT NULL DEFAULT '',
  `flags` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`,`keyword`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dahdi`
--

LOCK TABLES `dahdi` WRITE;
/*!40000 ALTER TABLE `dahdi` DISABLE KEYS */;
/*!40000 ALTER TABLE `dahdi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `iax`
--

DROP TABLE IF EXISTS `iax`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `iax` (
  `id` varchar(20) NOT NULL DEFAULT '-1',
  `keyword` varchar(30) NOT NULL DEFAULT '',
  `data` varchar(255) NOT NULL,
  `flags` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`,`keyword`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `iax`
--

LOCK TABLES `iax` WRITE;
/*!40000 ALTER TABLE `iax` DISABLE KEYS */;
/*!40000 ALTER TABLE `iax` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-30  4:03:49
